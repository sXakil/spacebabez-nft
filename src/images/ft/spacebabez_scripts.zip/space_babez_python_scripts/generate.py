from PIL import Image
from random import choices, choice
import json
from spaceGenerator import generateBG
from tattoGen import generateTattoo

def toMeta(traits, ticker):
    meta = {}
    meta["Ticker"] = f"SPACEBABEZ{ticker}"
    meta["Quantity"] = 1
    meta["Token Name"] = f"SPACEBABEZ #{ticker}"
    meta["Image Name"] = f"space_babez_{ticker:04}.png"
    meta["Description"] = "Space Babez were created to live forever on the Cardano Blockchain. There is a total of 9,999 unique Space Babez randomly generated for you to collect. No two Space Babez are alike, each one was generated from a selection of 172 variations in 16 different rarity categories which includes 1,120 different types of #boobs"
    meta["Alien Species"] = traits['Alien Species'].title()
    meta["Outfit"] = traits['Outfits'].replace("_", "-").title()
    meta["Boob Size"] = traits['Size'].title()
    meta["Hair"] = traits['Hair'].title()
    meta["Helmet"] = traits['Helmets'].title()
    meta["Accent Color"] = traits['Accent Color'].title()
    meta["Shoes"] = traits['Shoes'].title()
    meta["Accessories"] = traits['Accessories'].title()
    meta["Gloves"] = traits['Gloves'].title()
    meta["Earrings"] = traits['Earrings'].title()
    meta["Necklace"] = traits['Necklace'].title()
    meta["Weapon"] = traits['Weapon'].title()
    meta["Hairspray Bonus"] = traits['Hairspray'].title()
    if traits['Powers'] == [] or traits['Powers'] == "none":
	    meta["Power"] = "none".title()
    else:
	    meta["Power"] = " + ".join(i for i in traits['Powers']).title()
    meta["Stars"] = traits['Background'].title()
    meta["Signature"] = "Unknown"
    meta["Website"] = "www.spacebabez.io"
    meta["Author"] = "Anti.biz"
    meta["Copyright"] = "Copyright © Anti.biz"

    return meta

def toCsv(resultPath, data):
    with open(f"{resultPath}/result.csv", "w", encoding="utf-8") as f:
        f.write("|".join(b for b in data[0]) + "\n")
        for i in data:
            f.write("|".join(str(data[data.index(i)][b]) for b in data[data.index(i)]) + "\n")

def powerGenerator(traits):
    powers = []
    LatexPowerList = [traits["Shoes"] == "Latex Boots", traits["Gloves"] == "Latex", traits["Outfits"] == "Latex"]
    # Space Power
    if (traits["Helmets"].lower() == "yes" and traits["Outfits"] == "Space Suit" and traits["Weapon"] == "Space Blaster") and (traits["Gloves"] == "Space Gloves" or traits["Shoes"] == "Space Boots"):
        powers.append("space")
    # Dorothy Power
    if (traits["Shoes"] == "Rubys Slippers" or traits["Earrings"] == "Ruby") and (traits["Hair"] == "Dorothy"):
        powers.append("dorothy")
    # Cleopatra Power
    if (traits["Weapon"] == "Snake whip" or traits["Weapon"] == "Laser Whip") and (traits["Hair"] == "Cleopatra"):
        powers.append("cleopatra")
    # Leia Power
    if (traits["Weapon"] == "Green Laser Sword" or traits["Weapon"] == "Blue Laser Sword" or traits["Weapon"] == "Devil Blade" or traits["Weapon"] == "Pink Destiny Sword") and (traits["Hair"] == "Leia"):
        powers.append("leia")
    # Marilyn Power
    if (traits["Earrings"] == "Diamond" or traits["Earrings"] == "Emerald") and (traits["Hair"] == "Marilyn"):
        powers.append("marilyn")
    # Latex Power
    if LatexPowerList.count(True) >= 2:
        powers.append("latex")
    # Heart Power
    if (traits["Necklace"] == "Heart Choker") and (traits["Accessories"] == "Heart Glasses" or traits["Earrings"] == "Heart"):
        powers.append("heart")
    # Spiked Power
    if (traits["Necklace"] == "Spiked") and (traits["Shoes"] == "Spiked Thigh Highs" or traits["Gloves"] == "Spiked"):
        powers.append("spiked")
    # Pussy Power
    if (traits["Outfits"] == "Nude") and (traits["Gloves"] == "None"):
        powers.append("pussy")
    # Boob Power
    if traits["Size"] == "G":
        powers.append("boob")
    # Style Power
    if (traits["Necklace"] != "None" and traits["Gloves"] != "None" and traits["Shoes"] != "Barefoot" and traits["Accessories"] != "None" and traits["Earrings"] != "None") and (traits["Outfits"] != "Space Suit"):
        powers.append("style")
    if powers == []:
        return "none"
    return powers

run = True
stop = 9999
current = 0
startPath = "mainFiles"
resultPath = "results"
sign = Image.open("mainFiles\Signature\signature.png")
# specialNums = [9291, 6787, 6884, 9637, 2584, 8151, 9018, 642, 6569, 6821, 7330, 161, 5092, 2275, 3567, 8968, 9034, 1288, 4367, 9960, 3595, 1117, 2653, 5547, 3224, 622, 4078, 7390, 2617, 2859, 4383, 6203, 5414]
specialNums = []
p = [i for i in range(1, stop + 1)]
for i in range(33):
	a = choice(p)
	specialNums.append(a) #
	p.remove(a)
del p
print(specialNums)
# imageOrder = ["Power", "Hairspray", "Alien Species", "Tattoo", "Accent Color", "Accessories", "Outfit", "Necklace", "Hair", "Earrings", "Helmets", "Gloves", "Weapon", "Shoes"]
combanitions = []
metaDatas = []
with open("chancesAndPaths.json", "r") as f:
    chances = json.load(f)

# alienspecies_outfit_size.png
"""
1) Background (randomly generated stars)
2) Power 
3) Hairspray Bonus
4) Body
5) Generated Tattoo (Space Babez # on leg)
6) Accent Colors 
7) Necklace
8) Accessories
9) Outfit
10) Hair
11) Earrings (after hair, but before helmet)
12) Helmet
13) Gloves
14) Weapons
15) Shoes
"""

while run:
    currentCombain = {'Alien Species': 'Unknown', 'Outfits': 'Unknown', 'Size': 'Unknown', 'Helmets': "Unknown", 'Hair': 'Unknown', 'Accent Color': 'Unknown', 'Shoes': 'Unknown', 'Accessories': 'Unknown', 'Gloves': 'Unknown', 'Earrings': 'Unknown', 'Necklace': 'Unknown', 'Weapon': 'Unknown', 'Hairspray': 'Unknown', 'Background': 'Unknown', 'Powers': "Unknown"}
    toPaste = {}

    # Choosing Random
    for i in chances:
        """randomRarity = choices(list(chances[i].values()), list(map(float, list(chances[i].keys()))))[0]
        path = choice(randomRarity)"""

        path = choices(list(chances[i].keys()), list(chances[i].values()))[0] # New Method
        
        currentCombain[i] = path

    # Checking If There Is Powers
    if current + 1 in specialNums:
        currentCombain = {'Alien Species': currentCombain['Alien Species'], 'Outfits': 'Nude', 'Size': currentCombain['Size'], 'Helmets': "No", 'Hair': 'Dorothy', 'Accent Color': 'Red', 'Shoes': 'Ruby Slippers', 'Accessories': "None", 'Gloves': "None", 'Earrings': 'Ruby', 'Necklace': "Heart Choker", 'Weapon': 'Devil blade', 'Hairspray': 'Yes', 'Background': 'Red', 'Powers': 'Unknown'}
    currentPower = powerGenerator(currentCombain)
    currentCombain["Powers"] = currentPower

    if currentCombain["Outfits"] == "Space Suit" or currentCombain["Outfits"] == "Body Suit" or currentCombain["Outfits"] == "T_Shirt":
        imageOrder = ["Powers", "Hairspray", "Alien Species", "Tattoo", "Accent Color", "Accessories", "Gloves", "Weapon", "Necklace", "Outfit", "Hair", "Earrings", "Helmets", "Shoes"]
    else:
        imageOrder = ["Powers", "Hairspray", "Alien Species", "Tattoo", "Accent Color", "Accessories", "Gloves", "Weapon", "Outfit", "Necklace", "Hair", "Earrings", "Helmets", "Shoes"]

    # Checking If There Is Duplicates
    newCurrent = {i:currentCombain[i] for i in currentCombain if i!="Hairspray" and i!="Powers"}
    newCurrent["Powers"] = currentCombain["Powers"][0]
    newCurrentCombin = hash(frozenset(newCurrent.items()))
    if newCurrentCombin in combanitions:
        print(f"Found Duplicate! - {[currentCombain[i] for i in currentCombain]}")
    else:
        combanitions.append(newCurrentCombin)
        # Adding Successful One
        current += 1
        # Generating Space Background
        bgImage = generateBG(currentCombain["Background"])
        # bgImage = Image.open("transparent.png")
        # Setting Deafult Value For Tattoo
        currentCombain["Tattoo"] = "Tattoo"
        # Setting The Pasting Order
        for j in imageOrder:
            if j == "Outfit":
                toPaste[f"Outfits/{currentCombain['Alien Species']}"] = f"{currentCombain['Alien Species']}_{currentCombain['Outfits']}_{currentCombain['Size']}"
            elif currentCombain[j] != "none":
                if j == "Powers":
                    # pass
                    toPaste[f"Powers"] = currentCombain["Powers"][0] + "_power"
                elif j == "Helmets":
                    if currentCombain["Helmets"].lower() == "yes":
                        toPaste["Helmets"] = currentCombain["Hair"] + "_helmet"
                elif j == "Hair":
                    if currentCombain["Helmets"].lower() == "no":
                        toPaste["Hair"] = currentCombain["Hair"]
                elif j == "Hairspray":
                    if currentCombain["Hairspray"].lower() == "yes":
                        toPaste[f"Hairspray"] = "hairspray"
                else:
                    toPaste[j] = (currentCombain[j])
        # Opening All Of The Pictures
        images = []
        for x in toPaste:
            if x != "Tattoo":
                if x != "Outfit":
                    images.append(Image.open(f"{startPath}/{x}/{toPaste[x].lower().replace(' ', '_')}.png"))
            else:
                images.append("tattoo")
        
        if current % 100 == 0:
            print(f"Generating #{current}")
        # Pasting All Of The Images
        for i in images:
            if i == "tattoo":
                generateTattoo(bgImage, current)
                pass
            else:
                bgImage.paste(i, (0, 0), i)
        # bgImage.paste(sign, (0, 0), sign)
        if current > stop:
            run = False
        else:
            bgImage = bgImage.crop((0, 0, bgImage.size[0] - 24, bgImage.size[1]))
            tempPath = f'{resultPath}/pictures/space_babez_{current:04}.png'
            bgImage.save(tempPath, "PNG")
            # Writing metadata into json
            del currentCombain["Tattoo"]
            tempMeta = toMeta(currentCombain, current)
            metaDatas.append(tempMeta)
        
        if current == stop:
            run = False

# Following only for non transparent
rarityData = {"Alien Species": {}, "Outfit": {}, "Boob Size": {}, "Hair": {}, "Helmet": {}, "Accent Color": {}, "Shoes": {}, "Accessories": {}, "Gloves": {}, "Earrings": {}, "Necklace": {}, "Weapon": {}, "Power": {}, "Stars": {}}
needed = ["Alien Species", "Outfit", "Boob Size", "Hair", "Helmet", "Accent Color", "Shoes", "Accessories", "Gloves", "Earrings", "Necklace", "Weapon", "Power", "Stars"]

for i in metaDatas:
    for j in needed:
        if i[j] not in rarityData[j]:
            rarityData[j][i[j]] = 0
        rarityData[j][i[j]] += 1

scoreData = {}

for i in metaDatas:
    score = 0
    for j in needed:
        score += stop / rarityData[j][i[j]]

    scoreData[i["Image Name"]] = score

scoreData = sorted(list(scoreData.items()), key=lambda x: x[1], reverse=True)
print(len(scoreData))
newScoreData = []
for i in scoreData:
    if int(i[0].split("_")[-1].split(".")[0]) in specialNums:
        pass
    else:
        newScoreData.append(i[0])
print(newScoreData)
print(len(newScoreData))
newScoreData = newScoreData[:200]
sign = Image.open("mainFiles\Signature\signature.png")

c = 0
for i in metaDatas:
    if i["Signature"] != "Yes":
        if i["Image Name"] in newScoreData:
            i["Signature"] = "Yes"
            img = Image.open(f'results/pictures/{i["Image Name"]}')
            img.paste(sign, (0, 0), sign)
            img.save(f'results/pictures/{i["Image Name"]}', "PNG")
            c += 1
        else:
            i["Signature"] = "No"
    else:
        print("Error, " + str(i["Image Name"]))
            
toCsv(resultPath, metaDatas)
with open(f'{resultPath}/metadata.json', 'w', encoding='utf-8') as f:
    json.dump(metaDatas, f, indent=4, separators=(',', ': '), ensure_ascii=False)