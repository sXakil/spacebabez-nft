import io
import os
import csv
import time
import json
import random

from PIL import ImageDraw, ImageFont, Image

from config import *

FONT = ImageFont.truetype('./Assets/Font/04B_03__.ttf', 15)

WIDTH = 576
HEIGHT = 700


def genspecialNums(STOP, size: int):
    return random.sample(range(1, STOP+1), size)


def generate_power(traits):
    powers = []
    latex_power = traits["Outfits"] == "Latex" and (traits["Gloves"] == "Latex" or traits["Shoes"] == "Latex Boots")

    if (traits["Shoes"] == "Ruby Slippers" or traits["Earrings"] == "Ruby") and (traits["Hair"] == "Dorothy"):
        powers.append("dorothy")

    if (traits["Weapon"] == "Snake whip" or traits["Weapon"] == "Golden Laser Whip" or
        traits["Weapon"] == "Laser Whip") and (traits["Hair"] == "Cleopatra"):
        powers.append("cleopatra")

    if (traits["Earrings"] == "Diamond" or traits["Earrings"] == "Emerald") and (traits["Hair"] == "Marilyn"):
        powers.append("marilyn")

    if (traits["Weapon"] == "Green Laser Sword" or traits["Weapon"] == "Blue Laser Sword"
        or traits["Weapon"] == "Devil Blade" or traits["Weapon"] == "Pink Destiny Sword") and (
            traits["Hair"] == "Leia"):
        powers.append("leia")

    if (traits["Helmets"].lower() == "yes" and traits["Outfits"] == "Space Suit") and \
            (traits["Weapon"] == "Space Blaster" or traits["Gloves"] == "Space Gloves" or traits["Shoes"] == "Space "
                                                                                                             "Boots"):
        powers.append("space")

    if (traits["Outfits"] == "Nude") and (traits["Gloves"] == "None"):
        powers.append("pussy")

    if traits["Boob Size"] == "G":
        powers.append("boob")

    if (traits["Necklace"] == "Heart Choker" or traits["Earrings"] in ("Red Heart", "Green Heart")) and (
            traits["Accessories"] in ("Green Heart Glasses", "Red Heart Glasses")):
        powers.append("heart")

    if (traits["Necklace"] == "Spiked") and (traits["Shoes"] == "Spiked Garters" or traits["Gloves"] == "Spiked"):
        powers.append("spiked")

    if latex_power:
        powers.append("latex")

    if (traits["Necklace"] != "None" and traits["Gloves"] != "None" and traits["Shoes"] != "Barefoot" and
            traits["Accessories"] != "None" and traits["Earrings"] != "None" and traits["Boob Size"] == "D"):
        powers.append("style")

    if not powers:
        return ["none"]
    return powers


def get_file_structure(folder_path: str):
    file_structure = {}

    for p in os.listdir(folder_path):
        file_structure[p] = []
        for ap in os.listdir(f"{folder_path}/{p}"):
            file_structure[p].append(ap)

    return file_structure


stars = get_file_structure("Assets/Stars")


def open_image(image_name):
    return Image.open(image_name).resize((WIDTH, HEIGHT)).convert("RGBA")


def generate_stars(star_color):
    background = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))

    # Stars
    for _ in range(random.randint(50, 150)):
        i_star = random.choice(stars[star_color])
        j_star = Image.open(f"Assets/Stars/{star_color}/{i_star}")
        background.paste(j_star, (random.randint(50, 500), random.randint(0, HEIGHT)), j_star)

    return background


def generate_tattoo(back_image: Image.Image, tattoo_text: str):
    draw_canvas = ImageDraw.Draw(back_image)

    width = 316 - (len(tattoo_text) * 4) - 1
    draw_canvas.text((width, 363), str(tattoo_text), font=FONT, fill=(0, 0, 0))

    bytes_images = io.BytesIO()
    back_image.save(bytes_images, format="GIF")
    draw_canvas = Image.open(bytes_images).convert("RGBA")


def dump_metadata(characters: list, start_time, assets: dict, current: int, generated: int):
    data = []
    with open(f"{RESULTS_PATH}/metadata.json", "w", encoding="utf-8-sig") as f:
        for index, char in enumerate(characters, start=1):
            char["Helmet"] = char.pop("Helmets")
            char["Power"] = char.pop("Powers")
            char["Outfit"] = char.pop("Outfits")
            data.append({
                "Ticker": f"SPACEBABEZ{index}",
                "Quantity": 1,
                "Token Name": f"SPACEBABEZ #{index}",
                "Image Name": f"space_babez_{index:04}.gif",
                "Description": "Space Babez were created to live forever on the Cardano Blockchain. "
                               "There is a total of 6,666 unique Space Babez randomly generated "
                               "for you to collect. No two Space Babez are alike, each one was "
                               "generated from a selection of 259 variations in 16 different "
                               "rarity categories which includes 2,142 different types of #boobz",
                **char,
                "Website": "https://spacebabez.io",
                "Author": "Anti.biz",
                "Copyright": "Copyright \N{COPYRIGHT SIGN} Anti.biz"
            })

        json.dump(data, f, indent=4, ensure_ascii=False)

    end_time = time.time() - start_time

    with open(f"{RESULTS_PATH}/metadata.csv", "w", encoding="utf-8-sig") as f:
        inf = csv.writer(f, delimiter="|")

        inf.writerow([*data[0].keys()])

        for elem in data:
            inf.writerow([*elem.values()])

    with open(f"{RESULTS_PATH}/stats.json", "w", encoding="utf-8-sig") as f:
        json.dump({
            "totalTimeSeconds": round(end_time, 2),
            "totalGenerated": generated,
            "imagesGenerated": current - 1,
            "assetsPath": ASSETS_PATH,
            "resultsPath": RESULTS_PATH,
            "assetsUsed": assets
        }, f, indent=4)
