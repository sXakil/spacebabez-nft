import os
import copy
import json
import random
import time

import imageio
from tqdm import tqdm
from PIL import Image, ImageSequence

import helpers
from config import *

with open("./chancesAndPaths.json", "r") as f:
    chances = json.load(f)

# Modify as needed
progress = tqdm(total=STOP)

hashes: list = []
assets: dict = {}

dummy_dict = copy.deepcopy(chances)
for key, value in dummy_dict.items():
    if key.lower() == "power":
        key = "Powers"
        assets["Powers"] = {}
    else:
        assets[key] = {}
    for key1 in value:
        assets[key][key1] = 0
del dummy_dict

# Do not modify
GENERATED = 0  # Generated in total
CURRENT = 1  # Successful image generations
RUN = True  # Whether to generate or not

if not os.path.exists(f"{RESULTS_PATH}/pictures"):
    os.makedirs(f"{RESULTS_PATH}/pictures")

duplicates = []
characters = []

specialNums = helpers.genspecialNums(STOP, DOROTHY_COUNT)
startTime = time.time()

while RUN:
    character = dict.fromkeys([
        "Alien Species", "Outfits", "Boob Size", "Helmets", "Hair",
        "Accent Color", "Shoes", "Accessories", "Gloves", "Earrings",
        "Necklace", "Weapon", "Hairspray", "Powers", "Vortex",
    ])

    for key in chances:
        character[key] = random.choices(list(chances[key].keys()), list(chances[key].values()))[0]

    if CURRENT in specialNums:
        print(f"Found a dorothy numbered #{CURRENT}")
        # NOTE: character.update guarantees order
        character.update({
            'Outfits': 'Censored',
            'Hair': 'Dorothy',
            'Shoes': 'Ruby Slippers',
            'Accessories': "None",
            'Gloves': "None",
            'Helmets': "No",
            'Earrings': 'Ruby',
            'Weapon': 'Devil Blade'
        })

    # Verify duplicates
    hash_ = hash(frozenset(character.items()))
    if hash_ in hashes:
        GENERATED += 1
        print("-> Duplicate")
        continue
    else:
        hashes.append(hash_)

    # Create powers
    character["Powers"] = helpers.generate_power(character)
    del character["Power"]

    # create base image
    image = Image.new(COLOR_SPACE, (helpers.WIDTH, helpers.HEIGHT), (0, 0, 0, 0))

    suit_flag = any(i in character["Outfits"].lower() for i in ("space suit", "body suit"))
    scouter_flag = character["Accessories"].lower() == "scouter"
    hanging_necklace_flag = any(i in character["Outfits"].lower() for i in ("t_shirt", "t-shirt", "bulls eye")) and \
                            character["Necklace"].lower() in ("blood vial", "chain", "bullet", "lock", "dog tags")
    # decide image order, image stack
    if hanging_necklace_flag:
        imageOrder = [
            "Stars", "Powers", "Hairspray", "Alien Species", "Accent Color",
            "Shoes", "Gloves", "Weapon", "Necklace", "Outfits", "Hair", 'Boob Size',
            "Earrings", "Accessories", "Helmets", "Vortex"
        ]
    else:
        imageOrder = [
            "Stars", "Powers", "Hairspray", "Alien Species", "Accent Color",
            "Shoes", "Gloves", "Weapon", "Outfits", "Hair", 'Boob Size', "Necklace",
            "Earrings", "Accessories", "Helmets", "Vortex"
        ]

    if character["Hair"] in ("Marilyn", "Shaggy", "Braids", "Teased", "Curly", "Curl", "Leia", "Spiked",
                             "Fro", "Ponytail", "Shaved") and not scouter_flag:
        hair_idx = imageOrder.index("Hair")
        acc_idx = imageOrder.index("Accessories")
        imageOrder[hair_idx], imageOrder[acc_idx] = imageOrder[acc_idx], imageOrder[hair_idx]

        hair_idx = imageOrder.index("Hair")
        ear_idx = imageOrder.index("Earrings")
        imageOrder[hair_idx], imageOrder[ear_idx] = imageOrder[ear_idx], imageOrder[hair_idx]

    if suit_flag:
        imageOrder.remove("Necklace")

    hair = ""
    if character["Helmets"].lower() == "yes":
        hair = character['Hair']
        imageOrder.remove("Hair")

    for key in imageOrder:
        if key.lower() in ("vortex", "constellations", "boob size"):
            continue

        if key in character and isinstance(character[key], str) and character[key].lower() == "unknown":
            continue

        if key.lower() == "stars":
            im = helpers.generate_stars(character["Stars"])
        elif key.lower() == "outfits":
            prefix = ""
            if character[key].lower() == "green mini skirt":
                prefix = "light_"

            colorlessOutfits = ["topless", "swimsuit", "space_suit", "romper", "nude", "latex",
                                "crop_top", "censored", "bubbles", "bikini"]

            correct_name = "Grey" if character['Alien Species'].lower() == "gray" else character['Alien Species']
            if character[key].lower() in colorlessOutfits:
                if character["Boob Size"].lower() == "a" and character[key].lower() == "nude":
                    character["Boob Size"] = "B"
                imPath = f"{correct_name.title()}/{correct_name.lower()}_{prefix}" \
                         f"{character[key].lower().replace(' ', '_').replace('-', '_')}_" \
                         f"{character['Boob Size'].lower()}.png"
            else:
               # if character['Alien Species'].lower() == "bug":
                #    character[key] = character[key].replace("Pink", "").strip()
                # elif character['Alien Species'].lower() == "najdorf":
                #     character[key] = character[key].replace("Red", "").strip()

                splitOutfit = character[key].split()

                file_name = f"{correct_name}_{prefix}{character['Outfits'].replace(' ', '_').replace('-', '_')}" \
                            f"_{character['Boob Size']}.png"

                if len(splitOutfit) == 3:
                    if splitOutfit[0].lower() != "blue" and splitOutfit[1].lower() == "body" and \
                            splitOutfit[2].lower() == "suit":
                        file_name = f"{correct_name}_{prefix}{splitOutfit[1]}_{splitOutfit[2]}_" \
                                    f"{character['Boob Size']}.png"

                file_name = file_name.lower()
                imPath = f"{correct_name.title()}/{file_name}"

            im = Image.open(f"{ASSETS_PATH}/{key}/{imPath}")
        elif key.lower() == "powers":
            if character[key][0] != "none":
                im = Image.open(f"{ASSETS_PATH}/{key}/{character['Powers'][0]}_power.png")
            else:
                continue
        elif key.lower() == "helmets":
            if character["Helmets"].lower() == "yes":
                im = Image.open(f"{ASSETS_PATH}/{key}/{hair.replace(' ', '_').lower()}_helmet.png")
            else:
                continue
        elif key.lower() == "hairspray":
            if character[key].lower() == "yes":
                im = Image.open(f"{ASSETS_PATH}/{key}/hairspray.png")
            else:
                continue
        else:
            im = Image.open(f"{ASSETS_PATH}/{key}/{character[key].lower().replace(' ', '_')}.png")

        im = im.convert(COLOR_SPACE)
        # image = Image.alpha_composite(image, im)
        image.paste(im, (0, 0), im)

        # generate tattoo after alien species has been pasted
        if key.lower() == "alien species":
            helpers.generate_tattoo(back_image=image, tattoo_text=str(CURRENT))

    vortex = Image.open(f"{ASSETS_PATH}/Vortex/{character['Vortex'].lower().replace(' ', '_')}.gif")
    frames = []

    for gif_frame in ImageSequence.Iterator(vortex):
        frame = copy.deepcopy(gif_frame)
        frame = frame.convert(COLOR_SPACE).resize((helpers.WIDTH, helpers.HEIGHT))
        img = copy.deepcopy(image).convert(COLOR_SPACE)

        frame = Image.alpha_composite(frame, img)
        # frame.paste(img, (0, 0), img)
        frames.append(frame)

    character["Powers"] = ' + '.join(power.title() for power in character["Powers"])

    imageio.mimsave(f"{RESULTS_PATH}/pictures/space_babez_{CURRENT:04}.gif", frames, format='GIF', fps=50)

    characters.append(character)

    for key, value in character.items():
        if key == "Powers":
            for power in value.split(" + "):
                assets[key][power.title()] += 1
            continue

        if value in assets.get(key, {}):
            assets[key][value] += 1
        else:
            assets[key][value] = 1

    if CURRENT >= STOP:
        RUN = False
    CURRENT += 1
    GENERATED += 1
    progress.update(1)

helpers.dump_metadata(characters, startTime, assets, CURRENT, GENERATED)
