from PIL import ImageDraw, ImageFont

myFont = ImageFont.truetype('04B_03__.ttf', 15)
lines = []
    
def generateTattoo(x, num):
    num = str(num)
    d1 = ImageDraw.Draw(x)

    # width = 316 - (len(num) * 4) - 3 # retro_computer
    width = 316 - (len(num) * 4) - 1 # 04B_03

    d1.text((width, 363), str(num), font=myFont, fill = (0, 0, 0))
